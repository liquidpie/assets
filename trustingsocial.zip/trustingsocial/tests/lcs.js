'use strict';

const lcs = require('../routes/lcs');
const assert = require('assert');

function testLCSTwoElements() {
    var arr = ["AAAAAAAAAABABBBBBBBB", "BBBBBBBBBABAAAAAAAAA"];
    var expected = "ABA";

    try {
        var result = lcs.lcs(arr);

        assert.equal(expected, result, "Result doesn't match with expected LCS");
    } catch (error) {
        console.error("Test failed - testLCSTwoElements");
    }
}

function testLCSOneElement() {
    var arr = ["AAAAAAAAAABABBBBBBBB"];
    var expected = "";

    try {
        var result = lcs.lcs(arr);

        assert.equal(expected, result, "Result doesn't match with expected LCS");
    } catch (error) {
        console.error("Test failed - testLCSOneElement");
    }
}

function testLCSMultipleElements() {
    var arr = ["AAAAAAAAAABABBBBBBBB", "BBBBBBBBBABAAAAAAAAA", "BBBBBBBBBCBAAAAAAAAA"];
    var expected = "BA";

    try {
        var result = lcs.lcs(arr);

        assert.equal(expected, result, "Result doesn't match with expected LCS");
    } catch (error) {
        console.error("Test failed - testLCSMultipleElements");
    }
}

// Run tests
testLCSTwoElements();

testLCSOneElement();

testLCSMultipleElements();