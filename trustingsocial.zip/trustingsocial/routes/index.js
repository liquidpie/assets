'use strict';

const express = require('express');
const router  = express.Router();
const lcsRoute = require('./lcs');


/* GET home page. */
router.get('/', lcsRoute.landing);

router.get('/create_random_string', lcsRoute.nextRandomString);

router.post('/compute_longest_common_substring', lcsRoute.computeLCS);

module.exports = router;
