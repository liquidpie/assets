'use strict';

const landing = function (req, res) {
  res.render('lcs', { title: 'Trusting Social Problem' });
};

const nextRandomString = function (req, res) {
    var text = "";
    var alphabets = "ABCD";

    for (var i = 0; i < 20; i++) {
        text += alphabets.charAt(Math.floor(Math.random() * alphabets.length));
    }

    res.status(200).send(text);
};

const computeLCS = function (req, res) {
    var data = JSON.parse(JSON.stringify(req.body).replace('"data[]"', '"data"'));
    var arr = data.data;

    var result = lcs(arr);

    res.status(200).send(result);
};

String.prototype.replaceAt = function(index, replacement) {
    return this.substr(0, index) + replacement + this.substr(index + replacement.length);
};

const lcs = function (arr) {
    var n = arr.length;
    var result = "";
    var stem = arr[0];

    if (n > 1) {
        for (var i = 1; i < n; i++) {
            for (var j = 0; j < 20; j++) {
                if ((stem.charAt(j) !== "*") && (stem.charAt(j) !== arr[i].charAt(j))) {
                    stem = stem.replaceAt(j, "*");
                }
            }
        }

        var stemArray = stem.split("*");
        for (var i = 0; i < stemArray.length; i++) {
            result = stemArray[i].length > result.length ? stemArray[i] : result;
        }
    }

    return result;
};

module.exports = {
    landing : landing,
    nextRandomString : nextRandomString,
    computeLCS : computeLCS,
    lcs : lcs
};
