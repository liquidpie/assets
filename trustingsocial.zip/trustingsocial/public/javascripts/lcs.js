$(document).ready( function () {

    var rangeInput = $("#range-input");
    var nextBoxId = 1;

    var addBoxes = function (boxDiv) {
        for (var i = 1; i <= rangeInput.val(); i++) {
            var box = '<input type="text" name="box" id="box-' + i + '"/>';
            boxDiv.append(box);
        }
    };

    var getData = function () {
        nextBoxId = 1;
        for (var i = 1; i <= rangeInput.val(); i++) {
            $.ajax({
                url : '/create_random_string',
                method : 'GET',
                success : function (result) {
                    $('#box-' + nextBoxId).val(result);
                    nextBoxId++;
                },
                error : function (xhr, ex) {
                    console.log("unable to get data");
                }
            });
        }

        if (rangeInput.val() > 0) {
            getLCS();
        }
    };

    var getLCS = function () {
        $.ajax({
            url : '/compute_longest_common_substring',
            method : 'POST',
            dataType : "text",
            data : { 'data' : $('[name="box"]').map(function () { return this.value; }).get()},
            success : function (result) {
                console.log(result);
                $('#lcs-output').val(result);
            },
            error : function (xhr, ex) {
                console.log("unable to get data");
            }
        });
    };

    rangeInput.on("change", function () {
        var boxDiv = $('#lcs-boxes');
        boxDiv.empty();

        var val = Math.abs(parseInt(this.value, 10) || 1);
        this.value = val > 1000 ? 0 : val;

        // add input boxes after user input
        addBoxes(boxDiv);

        // get random string
        getData();

    });

    $("#lcs-form").submit(function (e) {
       e.preventDefault();
    });

    setInterval(getData, 5000);

});